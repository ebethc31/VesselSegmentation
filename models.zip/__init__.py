from .aspp import CustomSegmentationNetwork
from .asppcnn import ASPPCNN
from .ra_unet import MainArchitecture
from .unet_3d import Unet 